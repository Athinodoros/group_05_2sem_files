INSERT INTO PARTNER VALUES ('Athinodoros CORP', '1') ;
INSERT INTO PARTNER VALUES ('Bani Productions', '2') ;
INSERT INTO PARTNER VALUES ('Bo Solutions', '3') ;

insert into USERINFO VALUES (1, 'Klaus','Klauson','DK', null ,'admin' );
insert into USERINFO VALUES (2, 'Bancho','Petrov','NO','Bani Productions','partner' );
insert into USERINFO VALUES (3, 'Athinodoros','Sgouromallis','IS','Athinodoros CORP','partner' );
insert into USERINFO VALUES (4, 'Bo','Vilstrup','DK','Bo Solutions','partner' );

INSERT INTO USERATHENTICATION VALUES ( 'Klaus',1,'Klaus','klaus@Dell.com');
INSERT INTO USERATHENTICATION VALUES ( 'Bancho',2,'Bancho','Bancho@Bacholand.com');
INSERT INTO USERATHENTICATION VALUES ( 'Athinodoros',3,'Athinodoros','athinodoros.sgouromallis@hotmail.com');
INSERT INTO USERATHENTICATION VALUES ( 'Bo',4,'Bo','Bo@hotmail.com');


INSERT INTO PROJECT VALUES ( 1,'Athinodoros CORP','Title','This is a description','pending',null,null,13333);
INSERT INTO PROJECT VALUES ( 6,'Athinodoros CORP','Title','This is a description','finished',null,null,13333);

